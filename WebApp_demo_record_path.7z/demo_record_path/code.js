
/*
    This file is for non-generated application code written by
    the app developer.

    This file will NOT be overwritten by AppMaker when deploying the app.

    This file is NOT part of the project file (appm) saved using
    AppMaker, and it is the responsibility of the developer to keep
    a copy in a safe place together with any other user files.

    Generated UI controls/components can be accessed through the global
    variable "Controls".
    
    Example: To change the "text" property of a Button component with the
    reference name "myButton":

    Controls.myButton.text = "New text";

*/


/// <reference path="fp-components/FPComponents.d.ts" />
/// <reference path="rws-api/RWS.d.ts" />
/// <reference path="code_generated.js" />

'use strict';


/**
 * Set this variable to true to enable the graphical debug/log overlay.
 */
const ENABLE_DEBUG_OVERLAY = false;


/**
 * Set this variable to true to enable RWS library logging.
 */
const ENABLE_RWS_LOGGING = false;


/**
 * This function will be called after the app has been started,
 * after all static resources (e.g. App SDK) has been loaded by
 * the browser.
 * 
 * This is a good location for code that configures and initializes
 * the app.
 */
async function appLoaded() {

    const task = await RWS.Rapid.getTask("T_ROB1");
    await task.movePPToRoutine("ActualisationListeProgramme", false, "MainModule");
    await RWS.Rapid.startExecution({ cycleMode: "as_is" });
    // Add code here..

}


/**
 * This function will be called by the App SDK when the app is
 * brought to the background, i.e. being "deactivated".
 * 
 * This function should return true if successful, false if unsuccessful.
 */
async function appDeactivatedCustom() {

    // Add code here

    
    return true;

}


/**
 * This function will be called by the App SDK when the app is
 * brought to the foreground after being in the background,
 * i.e. being "activated".
 * This function is not called by the SDK when the app is started.
 * 
 * This function should return true if successful, false if unsuccessful.
 */
async function appActivatedCustom() {

    // Add code here


    return true;

}


/* ############################ */
/* ###### USER FUNCTIONS ###### */
/* ############################ */

// Add user functions below.

// Example: A button control has an onclick function configured
// as "myAction" in the visual editor.
// Define a function that should be called when the button is
// clicked:

// function myAction() {
//     console.log("The button was clicked!");
// }


function myAction() {

};



async function ActualisationProgramme(idProgram, nomProgram) {
    var task = await RWS.Rapid.getTask('T_ROB1');
    var data = await task.getData('MainModule', 'ChoixProgrammeDropDown');

    var string = nomProgram[0];
    await data.setValue(string);


};


async function ActualisationListe() {
    const __Dropdown_19 = new FPComponents.Dropdown_A();
    var TabProgramme = await RWS.Rapid.getData("T_ROB1", "MainModule", "ProgrammeExistant");
    var DimensionTab = await TabProgramme.getDimensions();
    const task = await RWS.Rapid.getTask("T_ROB1");
    await task.movePPToRoutine("ActualisationListeProgramme", false, "MainModule");
    await RWS.Rapid.startExecution({ cycleMode: "as_is" });


    for (let index = 0; index < DimensionTab[0]; index++) {
        __Dropdown_19.model.items[index] = await TabProgramme.getArrayItem(index + 1);

    }
    __Dropdown_19.model = __Dropdown_19.model;
}
